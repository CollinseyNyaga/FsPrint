#/bin/sh

mono ./bin/FsPrint
